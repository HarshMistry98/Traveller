# -*- coding: utf-8 -*-

from . import config
from . import customerdetails
from . import productdetails
from . import ordersdetails
from . import producttemplate
